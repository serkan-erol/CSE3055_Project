﻿using Kismet.Entities.DTOs;
using Kismet.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Kismet.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FabricController : ControllerBase
{
    private readonly IFabricRepository _repo;

    public FabricController(IFabricRepository repo)
    {
        _repo = repo;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll(CancellationToken cancellationToken)
        => Ok(await _repo.GetAllDtoAsync(cancellationToken));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id, CancellationToken cancellationToken)
    {
        var row = await _repo.GetByIdDtoAsync(id, cancellationToken);
        return row is null ? NotFound(new { error = "Fabric not found" }) : Ok(row);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateFabricDto dto, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        var created = await _repo.CreateAsync(dto, cancellationToken);
        return Created($"/api/fabric/{created.FabricID}", created);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateFabricDto dto, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        dto.FabricID = id;
        var updated = await _repo.UpdateAsync(dto, cancellationToken);
        return updated is null ? NotFound(new { error = "Fabric not found" }) : Ok(updated);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken cancellationToken)
        => (await _repo.DeleteAsync(id, cancellationToken)) ? Ok() : NotFound(new { error = "Fabric not found" });
}
