﻿using Kismet.Entities.DTOs;
using Kismet.Repository.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Kismet.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BatchController : ControllerBase
{
    private readonly IBatchRepository _repo;

    public BatchController(IBatchRepository repo)
    {
        _repo = repo;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll(CancellationToken cancellationToken)
        => Ok(await _repo.GetAllDtoAsync(cancellationToken));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id, CancellationToken cancellationToken)
    {
        var row = await _repo.GetByIdDtoAsync(id, cancellationToken);
        return row is null ? NotFound(new { error = "Batch not found" }) : Ok(row);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateBatchDto dto, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        var created = await _repo.CreateAsync(dto, cancellationToken);
        return Created($"/api/batch/{created.BatchID}", created);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] UpdateBatchDto dto, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid) return BadRequest(ModelState);
        dto.BatchID = id;
        var updated = await _repo.UpdateAsync(dto, cancellationToken);
        return updated is null ? NotFound(new { error = "Batch not found" }) : Ok(updated);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken cancellationToken)
        => (await _repo.DeleteAsync(id, cancellationToken)) ? Ok() : NotFound(new { error = "Batch not found" });
}
