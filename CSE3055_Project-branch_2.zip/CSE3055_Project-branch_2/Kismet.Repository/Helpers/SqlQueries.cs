namespace Kismet.Repository.Helpers;

/// <summary>
/// Centralized SQL query location
/// </summary>
public static class SqlQueries
{
    /// <summary>
    /// User table related queries
    /// </summary>
    public static class User
    {
        // Query for User entity (minimal fields)
        // Currently unused!
        public const string GetAll = @"
            SELECT 
                u.UserID,
                u.UserType,
                u.UserName,
                u.ContactEmail,
                u.ContactPhone
            FROM dbo.[User] u
            ORDER BY u.UserID";
            
        // Currently unused!
        public const string GetById = @"
            SELECT 
                u.UserID,
                u.UserType,
                u.UserName,
                u.ContactEmail,
                u.ContactPhone
            FROM dbo.[User] u
            WHERE u.UserID = @UserID";

        // Query for UserResponseDto
        public const string GetAllDto = @"
            SELECT 
                u.UserID,
                u.UserType,
                u.UserName,
                u.ContactEmail,
                u.ContactPhone,
                u.CreatedAt,
                u.LastUpdatedAt
            FROM dbo.[User] u
            ORDER BY u.UserID";

        public const string GetByIdDto = @"
            SELECT 
                u.UserID,
                u.UserType,
                u.UserName,
                u.ContactEmail,
                u.ContactPhone,
                u.CreatedAt,
                u.LastUpdatedAt
            FROM dbo.[User] u
            WHERE u.UserID = @UserID";

        public const string InsertCustomerUser = @"
            INSERT INTO dbo.[User] (UserName, ContactEmail, ContactPhone, PasswordHash, UserType)
            VALUES (@UserName, @ContactEmail, @ContactPhone, @PasswordHash, 'Customer');
            SELECT CAST(SCOPE_IDENTITY() as int);";

        public const string InsertEmployeeUser = @"
            INSERT INTO dbo.[User] (UserName, ContactEmail, ContactPhone, PasswordHash, UserType)
            VALUES (@UserName, @ContactEmail, @ContactPhone, @PasswordHash, 'Employee');
            SELECT CAST(SCOPE_IDENTITY() as int);";

        public const string UpdateUserName = @"
            UPDATE dbo.[User]
            SET 
                UserName = COALESCE(@UserName, UserName),
                LastUpdatedAt = sysdatetime()
            WHERE UserID = @UserID";

        public const string UpdateUserEmail = @"
            UPDATE dbo.[User]
            SET 
                ContactEmail = COALESCE(@ContactEmail, ContactEmail),
                LastUpdatedAt = sysdatetime()
            WHERE UserID = @UserID";

        public const string UpdateUserPhone = @"
            UPDATE dbo.[User]
            SET 
                ContactPhone = COALESCE(@ContactPhone, ContactPhone),
                LastUpdatedAt = sysdatetime()
            WHERE UserID = @UserID";

        public const string UpdateUserPassword = @"
            UPDATE dbo.[User]
            SET 
                PasswordHash = COALESCE(@PasswordHash, PasswordHash),
                LastUpdatedAt = sysdatetime()
            WHERE UserID = @UserID";

        public const string DeleteUser = "DELETE FROM dbo.[User] WHERE UserID = @UserID";
    }

    /// <summary>
    /// Customer table related queries
    /// </summary>
    public static class Customer
    {
        // Query for Customer entity (minimal fields)
        // Currently unused!
        public const string GetAll = @"
            SELECT 
                c.CustomerID,
                c.UserType,
                c.CustomerNumber,
                c.CustomerType,
                c.ReliabilityStatus
            FROM dbo.[Customer] c
            INNER JOIN dbo.[User] u ON u.UserID = c.CustomerID AND u.UserType = c.UserType
            ORDER BY c.CustomerID";
            
        // Currently unused!
        public const string GetById = @"
            SELECT 
                c.CustomerID,
                c.UserType,
                c.CustomerNumber,
                c.CustomerType,
                c.ReliabilityStatus
            FROM dbo.[Customer] c
            INNER JOIN dbo.[User] u ON u.UserID = c.CustomerID AND u.UserType = c.UserType
            WHERE c.CustomerID = @CustomerID";

        // Query for CustomerResponseDto (includes User fields)
        public const string GetAllDto = @"
            SELECT 
                c.CustomerID,
                c.CustomerNumber,
                c.CustomerType,
                c.ReliabilityStatus,
                u.UserName,
                u.ContactEmail,
                u.ContactPhone,
                u.CreatedAt
            FROM dbo.[Customer] c
            INNER JOIN dbo.[User] u ON u.UserID = c.CustomerID AND u.UserType = c.UserType
            ORDER BY c.CustomerID";

        public const string GetByIdDto = @"
            SELECT 
                c.CustomerID,
                c.CustomerNumber,
                c.CustomerType,
                c.ReliabilityStatus,
                u.UserName,
                u.ContactEmail,
                u.ContactPhone,
                u.CreatedAt
            FROM dbo.[Customer] c
            INNER JOIN dbo.[User] u ON u.UserID = c.CustomerID AND u.UserType = c.UserType
            WHERE c.CustomerID = @CustomerID";

        public const string InsertCustomer = @"
            INSERT INTO dbo.[Customer] (CustomerID, CustomerNumber, CustomerType, ReliabilityStatus)
            VALUES (@CustomerID, @CustomerNumber, @CustomerType, @ReliabilityStatus);";

        public const string UpdateCustomerType = @"
            UPDATE dbo.[Customer]
            SET 
                CustomerType = COALESCE(@CustomerType, CustomerType)
            WHERE CustomerID = @CustomerID";

        public const string UpdateCustomerReliability = @"
            UPDATE dbo.[Customer]
            SET 
                ReliabilityStatus = COALESCE(@ReliabilityStatus, ReliabilityStatus)
            WHERE CustomerID = @CustomerID";

        public const string DeleteCustomer = "DELETE FROM dbo.[Customer] WHERE CustomerID = @CustomerID";
    }

    /// <summary>
    /// Employee table related queries
    /// </summary>
    public static class Employee
    {
        // Query for Employee entity (minimal fields)
        // Currently unused!
        public const string GetAll = @"
            SELECT 
                e.EmployeeID,
                e.UserType,
                e.EmployeeNumber,
                e.EmployeeRole,
                e.AccessLevel
            FROM dbo.[Employee] e
            INNER JOIN dbo.[User] u ON u.UserID = e.EmployeeID AND u.UserType = e.UserType
            ORDER BY e.EmployeeID";
            
        // Currently unused!
        public const string GetById = @"
            SELECT 
                e.EmployeeID,
                e.UserType,
                e.EmployeeNumber,
                e.EmployeeRole,
                e.AccessLevel
            FROM dbo.[Employee] e
            INNER JOIN dbo.[User] u ON u.UserID = e.EmployeeID AND u.UserType = e.UserType
            WHERE e.EmployeeID = @EmployeeID";

        // Query for EmployeeResponseDto (includes User fields)
        public const string GetAllDto = @"
            SELECT 
                e.EmployeeID,
                e.EmployeeNumber,
                e.EmployeeRole,
                e.AccessLevel,
                u.UserName,
                u.ContactEmail,
                u.ContactPhone,
                u.CreatedAt
            FROM dbo.[Employee] e
            INNER JOIN dbo.[User] u ON u.UserID = e.EmployeeID AND u.UserType = e.UserType
            ORDER BY e.EmployeeID";

        public const string GetByIdDto = @"
            SELECT 
                e.EmployeeID,
                e.EmployeeNumber,
                e.EmployeeRole,
                e.AccessLevel,
                u.UserName,
                u.ContactEmail,
                u.ContactPhone,
                u.CreatedAt
            FROM dbo.[Employee] e
            INNER JOIN dbo.[User] u ON u.UserID = e.EmployeeID AND u.UserType = e.UserType
            WHERE e.EmployeeID = @EmployeeID";

        public const string InsertEmployee = @"
            INSERT INTO dbo.[Employee] (EmployeeID, EmployeeNumber, EmployeeRole, AccessLevel)
            VALUES (@EmployeeID, @EmployeeNumber, @EmployeeRole, @AccessLevel);";

        public const string UpdateEmployeeRole = @"
            UPDATE dbo.[Employee]
            SET 
                EmployeeRole = COALESCE(@EmployeeRole, EmployeeRole)
            WHERE EmployeeID = @EmployeeID";

        public const string UpdateEmployeeAccessLevel = @"
            UPDATE dbo.[Employee]
            SET 
                AccessLevel = COALESCE(@AccessLevel, AccessLevel)
            WHERE EmployeeID = @EmployeeID";

        public const string DeleteEmployee = "DELETE FROM dbo.[Employee] WHERE EmployeeID = @EmployeeID";
    }
    public static class Fabric
    {
        public const string GetAllDto = @"
            SELECT 
                FabricID, FabricType, Composition, Color, WeightPerUnit, StockQuantity, Description
            FROM dbo.[Fabric]
            ORDER BY FabricID;";

        public const string GetByIdDto = @"
            SELECT 
                FabricID, FabricType, Composition, Color, WeightPerUnit, StockQuantity, Description
            FROM dbo.[Fabric]
            WHERE FabricID = @FabricID;";

        public const string Insert = @"
            INSERT INTO dbo.[Fabric] (FabricType, Composition, Color, WeightPerUnit, StockQuantity, Description)
            VALUES (@FabricType, @Composition, @Color, @WeightPerUnit, @StockQuantity, @Description);
            SELECT CAST(SCOPE_IDENTITY() AS int);";

        public const string Update = @"
            UPDATE dbo.[Fabric]
            SET
                FabricType = @FabricType,
                Composition = @Composition,
                Color = @Color,
                WeightPerUnit = @WeightPerUnit,
                StockQuantity = @StockQuantity,
                Description = @Description
            WHERE FabricID = @FabricID;";

        public const string Delete = @"
            DELETE FROM dbo.[Fabric]
            WHERE FabricID = @FabricID;";
    }

    public static class Batch
    {
        public const string GetAllDto = @"
            SELECT
                b.BatchID, b.OrderID, b.ShipmentID, b.FabricID, b.BatchNumber, b.Quantity, b.BatchPrice,
                b.ProductionDate, b.QualityGrade, b.CreatedAt,
                f.FabricType, f.Color
            FROM dbo.[Batch] b
            INNER JOIN dbo.[Fabric] f ON f.FabricID = b.FabricID
            ORDER BY b.BatchID;";

        public const string GetByIdDto = @"
            SELECT
                b.BatchID, b.OrderID, b.ShipmentID, b.FabricID, b.BatchNumber, b.Quantity, b.BatchPrice,
                b.ProductionDate, b.QualityGrade, b.CreatedAt,
                f.FabricType, f.Color
            FROM dbo.[Batch] b
            INNER JOIN dbo.[Fabric] f ON f.FabricID = b.FabricID
            WHERE b.BatchID = @BatchID;";

        // BatchPrice: Latest UnitPrice.EquivalentTLPrice * Quantity
        public const string Insert = @"
            DECLARE @UnitTL decimal(18,2);

            SELECT TOP (1) @UnitTL = EquivalentTLPrice
            FROM dbo.[UnitPrice]
            WHERE FabricID = @FabricID
            ORDER BY UPID DESC;

            IF @UnitTL IS NULL
                THROW 50021, 'No UnitPrice found for this FabricID.', 1;

            INSERT INTO dbo.[Batch] (OrderID, ShipmentID, FabricID, BatchNumber, Quantity, BatchPrice, ProductionDate, QualityGrade)
            VALUES (@OrderID, @ShipmentID, @FabricID, @BatchNumber, @Quantity, (@UnitTL * @Quantity), @ProductionDate, @QualityGrade);

            SELECT CAST(SCOPE_IDENTITY() AS int);";

        public const string Update = @"
            DECLARE @UnitTL decimal(18,2);

            SELECT TOP (1) @UnitTL = EquivalentTLPrice
            FROM dbo.[UnitPrice]
            WHERE FabricID = @FabricID
            ORDER BY UPID DESC;

            IF @UnitTL IS NULL
                THROW 50022, 'No UnitPrice found for this FabricID.', 1;

            UPDATE dbo.[Batch]
            SET
                OrderID = @OrderID,
                ShipmentID = @ShipmentID,
                FabricID = @FabricID,
                BatchNumber = @BatchNumber,
                Quantity = @Quantity,
                BatchPrice = (@UnitTL * @Quantity),
                ProductionDate = @ProductionDate,
                QualityGrade = @QualityGrade
            WHERE BatchID = @BatchID;";

        public const string Delete = @"
            DELETE FROM dbo.[Batch]
            WHERE BatchID = @BatchID;";
    }
}