﻿using Kismet.Entities.DTOs;

namespace Kismet.Repository.Interfaces;

public interface IFabricRepository
{
    Task<IReadOnlyList<FabricResponseDto>> GetAllDtoAsync(CancellationToken cancellationToken = default);
    Task<FabricResponseDto?> GetByIdDtoAsync(int fabricId, CancellationToken cancellationToken = default);
    Task<FabricResponseDto> CreateAsync(CreateFabricDto dto, CancellationToken cancellationToken = default);
    Task<FabricResponseDto?> UpdateAsync(UpdateFabricDto dto, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(int fabricId, CancellationToken cancellationToken = default);
}
