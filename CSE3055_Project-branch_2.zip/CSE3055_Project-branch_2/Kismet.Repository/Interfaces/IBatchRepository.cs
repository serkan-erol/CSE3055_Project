﻿using Kismet.Entities.DTOs;

namespace Kismet.Repository.Interfaces;

public interface IBatchRepository
{
    Task<IReadOnlyList<BatchResponseDto>> GetAllDtoAsync(CancellationToken cancellationToken = default);
    Task<BatchResponseDto?> GetByIdDtoAsync(int batchId, CancellationToken cancellationToken = default);
    Task<BatchResponseDto> CreateAsync(CreateBatchDto dto, CancellationToken cancellationToken = default);
    Task<BatchResponseDto?> UpdateAsync(UpdateBatchDto dto, CancellationToken cancellationToken = default);
    Task<bool> DeleteAsync(int batchId, CancellationToken cancellationToken = default);
}
