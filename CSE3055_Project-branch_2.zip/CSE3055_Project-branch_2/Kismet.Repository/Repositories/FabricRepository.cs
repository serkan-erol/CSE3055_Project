﻿using Dapper;
using Kismet.Core.Data;
using Kismet.Entities.DTOs;
using Kismet.Repository.Helpers;
using Kismet.Repository.Interfaces;

namespace Kismet.Repository.Repositories;

public class FabricRepository : IFabricRepository
{
    private readonly IDbConnectionFactory _connectionFactory;

    public FabricRepository(IDbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IReadOnlyList<FabricResponseDto>> GetAllDtoAsync(CancellationToken cancellationToken = default)
    {
        using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);
        var rows = await connection.QueryAsync<FabricResponseDto>(
            new CommandDefinition(SqlQueries.Fabric.GetAllDto, cancellationToken: cancellationToken));
        return rows.ToList().AsReadOnly();
    }

    public async Task<FabricResponseDto?> GetByIdDtoAsync(int fabricId, CancellationToken cancellationToken = default)
    {
        using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);
        return await connection.QueryFirstOrDefaultAsync<FabricResponseDto>(
            new CommandDefinition(SqlQueries.Fabric.GetByIdDto, new { FabricID = fabricId }, cancellationToken: cancellationToken));
    }

    public async Task<FabricResponseDto> CreateAsync(CreateFabricDto dto, CancellationToken cancellationToken = default)
    {
        using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);

        var id = await connection.QuerySingleAsync<int>(
            new CommandDefinition(SqlQueries.Fabric.Insert, dto, cancellationToken: cancellationToken));

        return await GetByIdDtoAsync(id, cancellationToken)
               ?? throw new InvalidOperationException("Failed to retrieve created fabric.");
    }

    public async Task<FabricResponseDto?> UpdateAsync(UpdateFabricDto dto, CancellationToken cancellationToken = default)
    {
        using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);

        var affected = await connection.ExecuteAsync(
            new CommandDefinition(SqlQueries.Fabric.Update, dto, cancellationToken: cancellationToken));

        return affected == 0 ? null : await GetByIdDtoAsync(dto.FabricID, cancellationToken);
    }

    public async Task<bool> DeleteAsync(int fabricId, CancellationToken cancellationToken = default)
    {
        using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);
        var affected = await connection.ExecuteAsync(
            new CommandDefinition(SqlQueries.Fabric.Delete, new { FabricID = fabricId }, cancellationToken: cancellationToken));
        return affected > 0;
    }
}
