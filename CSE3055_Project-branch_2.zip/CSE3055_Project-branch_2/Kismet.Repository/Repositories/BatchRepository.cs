﻿using Dapper;
using Kismet.Core.Data;
using Kismet.Entities.DTOs;
using Kismet.Repository.Helpers;
using Kismet.Repository.Interfaces;

namespace Kismet.Repository.Repositories;

public class BatchRepository : IBatchRepository
{
    private readonly IDbConnectionFactory _connectionFactory;

    public BatchRepository(IDbConnectionFactory connectionFactory)
    {
        _connectionFactory = connectionFactory;
    }

    public async Task<IReadOnlyList<BatchResponseDto>> GetAllDtoAsync(CancellationToken cancellationToken = default)
    {
        using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);
        var rows = await connection.QueryAsync<BatchResponseDto>(
            new CommandDefinition(SqlQueries.Batch.GetAllDto, cancellationToken: cancellationToken));
        return rows.ToList().AsReadOnly();
    }

    public async Task<BatchResponseDto?> GetByIdDtoAsync(int batchId, CancellationToken cancellationToken = default)
    {
        using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);
        return await connection.QueryFirstOrDefaultAsync<BatchResponseDto>(
            new CommandDefinition(SqlQueries.Batch.GetByIdDto, new { BatchID = batchId }, cancellationToken: cancellationToken));
    }

    public async Task<BatchResponseDto> CreateAsync(CreateBatchDto dto, CancellationToken cancellationToken = default)
    {
        using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);

        var id = await connection.QuerySingleAsync<int>(
            new CommandDefinition(SqlQueries.Batch.Insert, dto, cancellationToken: cancellationToken));

        return await GetByIdDtoAsync(id, cancellationToken)
               ?? throw new InvalidOperationException("Failed to retrieve created batch.");
    }

    public async Task<BatchResponseDto?> UpdateAsync(UpdateBatchDto dto, CancellationToken cancellationToken = default)
    {
        using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);

        var affected = await connection.ExecuteAsync(
            new CommandDefinition(SqlQueries.Batch.Update, dto, cancellationToken: cancellationToken));

        return affected == 0 ? null : await GetByIdDtoAsync(dto.BatchID, cancellationToken);
    }

    public async Task<bool> DeleteAsync(int batchId, CancellationToken cancellationToken = default)
    {
        using var connection = await _connectionFactory.CreateConnectionAsync(cancellationToken);
        var affected = await connection.ExecuteAsync(
            new CommandDefinition(SqlQueries.Batch.Delete, new { BatchID = batchId }, cancellationToken: cancellationToken));
        return affected > 0;
    }
}
