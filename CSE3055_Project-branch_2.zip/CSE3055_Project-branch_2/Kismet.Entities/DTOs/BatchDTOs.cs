﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Kismet.Entities.DTOs;

public class BatchResponseDto
{
    public int BatchID { get; set; }
    public int OrderID { get; set; }
    public int ShipmentID { get; set; }
    public int FabricID { get; set; }
    public string BatchNumber { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal BatchPrice { get; set; }
    public DateTime? ProductionDate { get; set; }
    public string? QualityGrade { get; set; }
    public DateTime CreatedAt { get; set; }

    // Fabric join (kolaylık için)
    public string FabricType { get; set; } = string.Empty;
    public string? Color { get; set; }
}

public class CreateBatchDto
{
    [Required] public int OrderID { get; set; }
    [Required] public int ShipmentID { get; set; }
    [Required] public int FabricID { get; set; }

    [Required, StringLength(50)]
    public string BatchNumber { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int Quantity { get; set; }

    public DateTime? ProductionDate { get; set; }

    [StringLength(50)]
    public string? QualityGrade { get; set; }
}

public class UpdateBatchDto
{
    [JsonIgnore]
    public int BatchID { get; set; }

    [Required] public int OrderID { get; set; }
    [Required] public int ShipmentID { get; set; }
    [Required] public int FabricID { get; set; }

    [Required, StringLength(50)]
    public string BatchNumber { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int Quantity { get; set; }

    public DateTime? ProductionDate { get; set; }

    [StringLength(50)]
    public string? QualityGrade { get; set; }
}
