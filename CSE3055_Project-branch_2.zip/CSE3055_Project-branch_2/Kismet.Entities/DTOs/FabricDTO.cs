﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Kismet.Entities.DTOs;

public class FabricResponseDto
{
    public int FabricID { get; set; }
    public string FabricType { get; set; } = string.Empty;
    public string? Composition { get; set; }
    public string? Color { get; set; }
    public decimal? WeightPerUnit { get; set; }
    public int StockQuantity { get; set; }
    public string? Description { get; set; }
}

public class CreateFabricDto
{
    [Required, StringLength(100)]
    public string FabricType { get; set; } = string.Empty;

    [StringLength(200)]
    public string? Composition { get; set; }

    [StringLength(50)]
    public string? Color { get; set; }

    public decimal? WeightPerUnit { get; set; }

    public int StockQuantity { get; set; } = 0;

    [StringLength(255)]
    public string? Description { get; set; }
}

public class UpdateFabricDto
{
    [JsonIgnore]
    public int FabricID { get; set; }

    [Required, StringLength(100)]
    public string FabricType { get; set; } = string.Empty;

    [StringLength(200)]
    public string? Composition { get; set; }

    [StringLength(50)]
    public string? Color { get; set; }

    public decimal? WeightPerUnit { get; set; }

    public int StockQuantity { get; set; }

    [StringLength(255)]
    public string? Description { get; set; }
}
